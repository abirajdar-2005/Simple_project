import java.io.*; import javax.servlet.*; import javax.servlet.http.*;
public class LoginServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
    String u = req.getParameter("username");
    String p = req.getParameter("password");
    if (u.equals("admin") && p.equals("1234"))
      res.sendRedirect("dashboard.html");
    else
      res.getWriter().println("Invalid login");
  }
}