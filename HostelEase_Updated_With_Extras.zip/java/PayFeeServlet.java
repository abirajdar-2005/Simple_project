import javax.servlet.*; import javax.servlet.http.*; import java.io.*; import java.sql.*;
public class PayFeeServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
    String roll = req.getParameter("roll");
    int amount = Integer.parseInt(req.getParameter("amount"));
    try (Connection con = DBConnection.getConnection()) {
      PreparedStatement ps = con.prepareStatement("INSERT INTO fees (roll, amount, status) VALUES (?, ?, 'Paid')");
      ps.setString(1, roll); ps.setInt(2, amount);
      ps.executeUpdate();
      res.getWriter().println("<script>alert('Fee paid');location='dashboard.html';</script>");
    } catch (Exception e) { e.printStackTrace(); }
  }
}