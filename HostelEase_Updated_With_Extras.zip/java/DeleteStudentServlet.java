import javax.servlet.*; import javax.servlet.http.*; import java.io.*; import java.sql.*;
public class DeleteStudentServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
    String roll = req.getParameter("roll");
    try (Connection con = DBConnection.getConnection()) {
      PreparedStatement ps = con.prepareStatement("DELETE FROM students WHERE roll=?");
      ps.setString(1, roll);
      ps.executeUpdate();
      res.getWriter().println("<script>alert('Deleted');location='dashboard.html';</script>");
    } catch (Exception e) { e.printStackTrace(); }
  }
}