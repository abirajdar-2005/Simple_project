import javax.servlet.*; import javax.servlet.http.*; import java.io.*; import java.sql.*;
public class UpdateRoomServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
    String roll = req.getParameter("roll");
    String room = req.getParameter("room");
    try (Connection con = DBConnection.getConnection()) {
      PreparedStatement ps = con.prepareStatement("UPDATE rooms SET room_no=? WHERE roll=?");
      ps.setString(1, room); ps.setString(2, roll);
      ps.executeUpdate();
      res.getWriter().println("<script>alert('Room updated');location='dashboard.html';</script>");
    } catch (Exception e) { e.printStackTrace(); }
  }
}