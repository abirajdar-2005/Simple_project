import javax.servlet.*; import javax.servlet.http.*; import java.io.*; import java.sql.*;
public class UpdateStudentServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
    String oldRoll = req.getParameter("old_roll");
    String newName = req.getParameter("new_name");
    String newRoll = req.getParameter("new_roll");
    try (Connection con = DBConnection.getConnection()) {
      PreparedStatement ps = con.prepareStatement("UPDATE students SET name=?, roll=? WHERE roll=?");
      ps.setString(1, newName); ps.setString(2, newRoll); ps.setString(3, oldRoll);
      ps.executeUpdate();
      res.getWriter().println("<script>alert('Updated');location='dashboard.html';</script>");
    } catch (Exception e) { e.printStackTrace(); }
  }
}